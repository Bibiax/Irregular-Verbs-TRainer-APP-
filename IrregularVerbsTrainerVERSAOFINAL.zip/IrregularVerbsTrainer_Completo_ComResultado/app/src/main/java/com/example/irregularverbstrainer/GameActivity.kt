package com.example.irregularverbstrainer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog
import com.example.irregularverbstrainer.R
import com.example.irregularverbstrainer.ResultActivity
import com.example.irregularverbstrainer.VerbFragment
import com.example.irregularverbstrainer.model.Verb
import com.example.irregularverbstrainer.utils.VerbLoader

class GameActivity : AppCompatActivity() {

    private lateinit var verbs: List<Verb>
    private var currentVerbIndex = 0
    private var currentStep = 1 // 1 = past, 2 = participle
    private var score = 0
    private var totalQuestions = 0
    private var questionsAnswered = 0  // ⭐ variavel pra criacao do menu

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        // Carrega os verbos do JSON
        verbs = VerbLoader.loadVerbs(this)
        // Linha para verificar se os verbos foram carregados
        android.util.Log.d("GameActivity", "Verbos carregados: ${verbs.size}")

        // ⭐ ADICIONE ESTAS 3 LINHAS:
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        btnMenu.setOnClickListener {
            showExitDialog()
        }

        // Inicia o jogo
        startGame()
    }

    private fun startGame() {
        if (verbs.isEmpty()) {
            showResult()
            return
        }

        // Embaralha os verbos para variedade
        verbs = verbs.shuffled()
        currentVerbIndex = 0
        currentStep = 1
        score = 0
        questionsAnswered = 0  // ⭐ INICIALIZA A VARIÁVEL
        totalQuestions = verbs.size * 2 // 2 perguntas por verbo

        // Inicia com a primeira pergunta
        askNextQuestion()
    }

    private fun askNextQuestion() {
        if (currentVerbIndex >= verbs.size && currentStep == 2) {
            showResult()
            return
        }

        if (currentVerbIndex >= verbs.size) {
            // Passa para a próxima etapa (participle)
            currentStep = 2
            currentVerbIndex = 0
        }

        val currentVerb = verbs[currentVerbIndex]
        val fragment = VerbFragment.newInstance(currentVerb, currentStep)

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()

        currentVerbIndex++
    }

    // ⭐ ADICIONE ESTE MÉTODO NOVO:
    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("Finalizar Treino")
            .setMessage("Deseja ver sua pontuação atual?\n\n" +
                    "Progresso: ${questionsAnswered}/$totalQuestions questões\n" +
                    "Acertos: $score")
            .setPositiveButton("Ver Pontuação") { _, _ ->
                showResultEarly()
            }
            .setNegativeButton("Continuar", null)
            .show()
    }

    // ⭐ ADICIONE ESTE MÉTODO NOVO:
    private fun showResultEarly() {
        val intent = Intent(this, ResultActivity::class.java)
        intent.putExtra("score", score)
        intent.putExtra("total", questionsAnswered) // ⭐ Usa questionsAnswered em vez de totalQuestions
        intent.putExtra("completed_early", true)
        startActivity(intent)
        finish()
    }

    private fun showResult() {
        val intent = Intent(this, ResultActivity::class.java)
        intent.putExtra("score", score)
        intent.putExtra("total", totalQuestions)
        intent.putExtra("completed_early", false)
        startActivity(intent)
        finish()
    }

    // Função para ser chamada quando a resposta estiver correta
    fun onAnswerCorrect() {
        score++
        questionsAnswered++  // ⭐ ADICIONE ESTA LINHA
        askNextQuestion()
    }

    // Função para ser chamada quando a resposta estiver incorreta
    fun onAnswerIncorrect() {
        questionsAnswered++  // ⭐ ADICIONE ESTA LINHA
        askNextQuestion()
    }
}