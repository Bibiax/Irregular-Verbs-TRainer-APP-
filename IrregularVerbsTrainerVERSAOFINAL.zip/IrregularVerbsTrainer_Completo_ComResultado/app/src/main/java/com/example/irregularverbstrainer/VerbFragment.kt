package com.example.irregularverbstrainer

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.irregularverbstrainer.model.Verb

class VerbFragment : Fragment() {

    companion object {
        fun newInstance(verb: Verb, step: Int): VerbFragment {
            val fragment = VerbFragment()
            val args = Bundle()
            args.putSerializable("verb", verb)
            args.putInt("step", step)
            fragment.arguments = args
            return fragment
        }
    }

    private lateinit var verb: Verb
    private var step: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            verb = it.getSerializable("verb") as Verb
            step = it.getInt("step")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_verb_input, container, false)

        val prompt = view.findViewById<TextView>(R.id.textViewPrompt)
        val verbText = view.findViewById<TextView>(R.id.textViewBaseVerb)
        val input = view.findViewById<EditText>(R.id.editTextAnswer)
        val button = view.findViewById<Button>(R.id.buttonSubmit)
        val feedbackLayout = view.findViewById<LinearLayout>(R.id.feedbackLayout)
        val feedbackText = view.findViewById<TextView>(R.id.textViewFeedback)
        val tryAgain = view.findViewById<Button>(R.id.buttonTryAgain)
        val showAnswer = view.findViewById<Button>(R.id.buttonShowAnswer)

        val correct = if (step == 1) verb.past else verb.participle

        //modifiquei o "forma do passado" e "forma do passado particípio"
        prompt.text = if (step == 1) "Past Simple" else "Past Participle"
        verbText.text = "${verb.base} (${verb.translation})"

        button.setOnClickListener {
            val answer = input.text.toString().trim().lowercase()
            feedbackLayout.visibility = View.VISIBLE

            if (answer == correct.lowercase()) {
                // Resposta correta
                feedbackText.text = "Correto!"
                feedbackText.setTextColor(Color.parseColor("#388E3C"))
                tryAgain.visibility = View.GONE
                showAnswer.visibility = View.GONE

                // Avança só depois de 1 segundo
                view.postDelayed({
                    (activity as? GameActivity)?.onAnswerCorrect()
                }, 1000)

            } else {
                // Resposta errada
                feedbackText.text = "Incorreto!"
                feedbackText.setTextColor(Color.parseColor("#D32F2F"))
                tryAgain.visibility = View.VISIBLE
                showAnswer.visibility = View.VISIBLE
            }
        }

        tryAgain.setOnClickListener {
            input.setText("")
            feedbackLayout.visibility = View.GONE
        }

        showAnswer.setOnClickListener {
            feedbackText.text = "Resposta: $correct"
            feedbackText.setTextColor(Color.parseColor("#1976D2"))
            tryAgain.visibility = View.GONE
            showAnswer.visibility = View.GONE

            // Depois de mostrar a resposta, avança em 2 segundos
            view.postDelayed({
                (activity as? GameActivity)?.onAnswerIncorrect()
            }, 2000)
        }

        return view
    }
}