package com.example.irregularverbstrainer

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.example.irregularverbstrainer.model.Verb

class VerbPagerAdapter(
    val context: Context,
    val verbs: List<Verb>
) : RecyclerView.Adapter<VerbPagerAdapter.VerbViewHolder>() {

    class VerbViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val text: TextView = itemView.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VerbViewHolder {
        val textView = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_1, parent, false)
        return VerbViewHolder(textView)
    }

    override fun onBindViewHolder(holder: VerbViewHolder, position: Int) {
        val verb = verbs[position]
        holder.text.text = "Verbo: ${verb.base} (${verb.translation})"
    }

    override fun getItemCount(): Int = verbs.size
}
