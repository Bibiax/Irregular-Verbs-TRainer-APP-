package com.example.irregularverbstrainer.model

import java.io.Serializable

data class Verb(
    val base: String,
    val past: String,
    val participle: String,
    val translation: String
) : Serializable
