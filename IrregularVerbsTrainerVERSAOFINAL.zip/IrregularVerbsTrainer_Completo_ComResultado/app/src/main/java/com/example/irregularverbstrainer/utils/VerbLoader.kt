package com.example.irregularverbstrainer.utils

import android.content.Context
import com.example.irregularverbstrainer.model.Verb
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object VerbLoader {
    fun loadVerbs(context: Context): List<Verb> {
        val json = context.assets.open("verbs.json")
            .bufferedReader().use { it.readText() }
        val type = object : TypeToken<List<Verb>>() {}.type
        return  Gson().fromJson(json, type)
    }
}
