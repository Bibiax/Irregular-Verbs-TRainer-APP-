package com.example.irregularverbstrainer


import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.irregularverbstrainer.databinding.ActivityMainBinding

// import com.example.irregularverbstrainer.utils.VerbLoader
// import com.example.irregularverbstrainer.adapters.VerbPagerAdapter

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

      override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

          Log.d("DEBUG", "GameActivity onCreate chamado") // ← ADICIONE ISSO
          Log.d("DEBUG", "setContentView concluído") // ← E ISSO
       // Botão "Começar" abre o GameActivity
        binding.startButton.setOnClickListener {
            val intent = Intent(this, GameActivity::class.java)
            startActivity(intent)
        }
    }
}
